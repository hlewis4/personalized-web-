package com.pw.anand.dao;

public class SqlConstants
{
	/*public static final String SQL_CHECK_LOGIN="select userid from users where userid=?";
	
	public static final String SQL_INSERT_USER_INFO="insert into users(userid,username,password,dob,gender,email,mobile,address,usertype) values(?,?,?,?,?,?,?,?,?)";
	*/
	public static final String SQL_LOGIN_CHECK="select role,USERNAME from users where USERID=? and PASSWORD=?";

	public static final String SQL_SAVE_USER_DETAILS = "insert into users(userid,username,email,mobile,role,password) values(?,?,?,?,?,?)";

	public static final String SQL_GET_USER_DETAILS = "select userid,username,email from users where role != 'ADMIN' and role=?";
	
	/*public static final String SQL_UPLOAD_VOTER_DETAILS = "insert into voters(voterid,votername,location) values(?,?,?)";
	
	public static final String SQL_GET_VOTER_DETAILS = "select voterid,votername from voters";

	public static final String SQL_SAVE_VOTER_DETAILS = "update voters set dob=?,father=?,occupation=?,gender=?,address=?,email=?,role=?,password=? where voterid=? ";

	public static final String SQL_CHECK_VOTERID = "select voterid from voters where voterid=? and votername=?";

	public static final String SQL_CHECK_REGISTERED_OR_NOT = "select email from voters where voterid=?";

	public static final String SQL_UPLOAD_SECRET_DETAILS = "insert into secretquestions(voterid,answer1,answer2,answer3) values(?,?,?,?)";

	public static final String SQL_UPLOAD_CANDIDATE_DETAILS = "insert into candidates(id,name,type,location,party,image) values(?,?,?,?,?,?)";
	
	public static final String SQL_VOTER_LOGIN_CHECK="select role,VOTERNAME,location,email from voters where voterid=? and PASSWORD=?";

	public static final String SQL_GET_CANDIDATE_DETAILS =  "select id,name,type,party,image from candidates where location=?";

	public static final String SQL_CHECK_SECRET_DETAILS = "select * from secretquestions where voterid='5637456' and answer1='zphs' and answer2='tuni' and answer3='8:30'";
	*/
}
