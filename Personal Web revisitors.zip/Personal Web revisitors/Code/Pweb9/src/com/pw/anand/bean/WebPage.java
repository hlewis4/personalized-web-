package com.pw.anand.bean;

import java.io.Serializable;

public class WebPage implements Serializable {

	private static final long serialVersionUID = 7827544260685528172L;
	private String wssno;
	private String url;
	private String desc;
	private String meta;

	public String getWssno() {
		return wssno;
	}

	public void setWssno(String wssno) {
		this.wssno = wssno;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getMeta() {
		return meta;
	}

	public void setMeta(String meta) {
		this.meta = meta;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("WebPage [wssno=");
		builder.append(wssno);
		builder.append(", url=");
		builder.append(url);
		builder.append(", desc=");
		builder.append(desc);
		builder.append(", meta=");
		builder.append(meta);
		builder.append("]");
		return builder.toString();
	}

}
