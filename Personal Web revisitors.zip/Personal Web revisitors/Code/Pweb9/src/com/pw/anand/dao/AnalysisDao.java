package com.pw.anand.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.pw.anand.util.DBUtil;

public class AnalysisDao {

	public List<Float> getQuestionnaireResult() {List<Float> result = new ArrayList<Float>();
		try {
			Connection con = DBUtil.getInstance().getConnection();

			PreparedStatement pst = con
					.prepareStatement("select avg(Q1ANS), avg(Q2ANS), avg(Q3ANS), avg(Q4ANS), avg(Q5ANS), avg(Q6ANS), avg(Q7ANS) from FEEDBACK");

			ResultSet rs = pst.executeQuery();
			
			while (rs.next()) {
				result.add(0, rs.getFloat(1));
				result.add(1, rs.getFloat(2));
				result.add(2, rs.getFloat(3));
				result.add(3, rs.getFloat(4));
				result.add(4, rs.getFloat(5));
				result.add(5, rs.getFloat(6));
				result.add(6, rs.getFloat(7));
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return result;
	}

	public boolean putUserAnswer(List<Integer> answer, String uid) 
	{
		boolean flag = false;
		int c=0;

		try {
			Connection con = DBUtil.getInstance().getConnection();
			
			PreparedStatement ps=con.prepareStatement("select username from feedback where username=?");
			ps.setString(1, uid);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				c=1;
			}
			ps.close();
			if(c==0)
			{
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			System.out.println(dateFormat.format(date));
			PreparedStatement pst = con
					.prepareStatement("Insert into FEEDBACK values((select nvl(max(FNO),500)+1 from FEEDBACK),?,?,?,?,?,?,?,?,?,?)");

			pst.setInt(1, answer.get(0));
			pst.setInt(2, answer.get(1));
			pst.setInt(3, answer.get(2));
			pst.setInt(4, answer.get(3));
			pst.setInt(5, answer.get(4));
			pst.setInt(6, answer.get(5));
			pst.setInt(7, answer.get(6));
			pst.setString(8, dateFormat.format(date));
			pst.setString(9, uid);
			pst.setString(10, null);
			int i = pst.executeUpdate();
			if (i == 1) {
				con.commit();
				flag = true;
			} else {
				con.rollback();
			}
			DBUtil.getInstance().closeConnection();

			}
			else
			{
				System.out.println("already given");
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return flag;
	}
}
