package com.pw.anand.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class ActivityTree {
	public Map<String, HashMap<String, Set<String>>> getActivityHistory() {

		Map<String, HashMap<String, Set<String>>> h = new HashMap<String, HashMap<String, Set<String>>>();
		try {

			Connection con = DBUtil.getInstance().getConnection();

			PreparedStatement pst = con.prepareStatement("select * from SEARCH_HISTORY");

			ResultSet rs = pst.executeQuery();
			String ctx="";
			String ctn="";

			while (rs.next()) {

				ctx=rs.getString("CONTEXT");
				ctn=rs.getString("CONTENT");
				if (h.containsKey("all")) {

					if (h.get("all").containsKey(ctx)) {
						HashMap<String, Set<String>> hh = h.get("all");
						Set<String> al = hh.get(ctx);
						al.add(ctn);
						hh.put(ctx, al);
						h.put("all", hh);

					} else {
						System.out.println("yes");
						HashMap<String, Set<String>> hh =h.get("all");
						Set<String> al = new HashSet<String>();
						al.add(ctn);
						hh.put(ctx, al);
						h.put("all", hh);

					}

				} else {
					// System.out.println("no");
					HashMap<String, Set<String>> hh = new HashMap<String, Set<String>>();
					Set<String> al = new HashSet<String>();
					al.add(ctn);
					hh.put(ctx, al);
					h.put("all", hh);
					System.out.println("h" + h + ", hh" + hh + ", al" + al);
				}

				/*
				 * System.out.println(resultSet.getString("last_visited").substring
				 * (0,10) + "URL [" + resultSet.getString("url") + "]" +
				 * ", visit count [" + resultSet.getString("visit_count") +
				 * "]");
				 */
			}

		}

		catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
		}

		return h;
	}
}
