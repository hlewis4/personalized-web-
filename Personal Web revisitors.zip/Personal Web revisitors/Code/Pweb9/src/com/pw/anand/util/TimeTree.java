package com.pw.anand.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class TimeTree {

	public String getKey(String month) {

		String key = null;
		int m = 0;
		if (month != null || month.trim().length() > 0) {
			m = Integer.valueOf(month.trim());
		}

		switch (m) {
		case 1:
			key = "Jan";
			break;
		case 2:
			key = "Feb";
			break;
		case 3:
			key = "Mar";
			break;
		case 4:
			key = "Apr";
			break;
		case 5:
			key = "May";
			break;
		case 6:
			key = "Jun";
			break;
		case 7:
			key = "Jul";
			break;
		case 8:
			key = "Aug";
			break;
		case 9:
			key = "Sep";
			break;
		case 10:
			key = "Oct";
			break;
		case 11:
			key = "Nov";
			break;
		case 12:
			key = "Dec";
			break;
		default:
			break;
		}

		return key;

	}

	public String getValue(String month, String day) {

		String key = null;
		int m = 0;
		int d = 0;
		if (month != null || month.trim().length() > 0) {
			m = Integer.valueOf(month.trim());
		}
		if (day != null || day.trim().length() > 0) {
			d = Integer.valueOf(day.trim());
		}

		switch (m) {
		case 1:
			key = "Jan";
			break;
		case 2:
			key = "Feb";
			break;
		case 3:
			key = "Mar";
			break;
		case 4:
			key = "Apr";
			break;
		case 5:
			key = "May";
			break;
		case 6:
			key = "Jun";
			break;
		case 7:
			key = "Jul";
			break;
		case 8:
			key = "Aug";
			break;
		case 9:
			key = "Sep";
			break;
		case 10:
			key = "Oct";
			break;
		case 11:
			key = "Nov";
			break;
		case 12:
			key = "Dec";
			break;
		default:
			break;
		}

		if (d <= 10) {
			key = "Early " + key;
		} else if (d <= 20) {
			key = "Middle " + key;
		} else {
			key = "Last " + key;
		}
		return key;

	}

	public Map<String, HashMap<String, Set<String>>> getGCHistory() {

		Map<String, HashMap<String, Set<String>>> h = new HashMap<String, HashMap<String, Set<String>>>();
		try {

			Connection con = DBUtil.getInstance().getConnection();

			PreparedStatement pst = con.prepareStatement("select * from SEARCH_HISTORY");

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				System.out.println(1);
				String[] dateinfo = rs.getString("LADATE").substring(0,
						10).split("-");
				// System.out.println(dateinfo[0]+dateinfo[1]+dateinfo[2]);

				if (h.containsKey(dateinfo[0].trim())) {

					if (h.get(dateinfo[0].trim()).containsKey(
							getKey(dateinfo[1]))) {
						HashMap<String, Set<String>> hh = h.get(dateinfo[0]);
						Set<String> al = hh.get(getKey(dateinfo[1]));
						al.add(getValue(dateinfo[1], dateinfo[2]));
						hh.put(getKey(dateinfo[1]), al);
						h.put(dateinfo[0], hh);
						// System.out.println("h"+h+", hh"+hh+", al"+al);

					} else {
						System.out.println("yes");
						HashMap<String, Set<String>> hh = h.get(dateinfo[0]);
						Set<String> al = new HashSet<String>();
						al.add(getValue(dateinfo[1], dateinfo[2]));
						hh.put(getKey(dateinfo[1]), al);
						h.put(dateinfo[0], hh);

					}

				} else {
					// System.out.println("no");
					HashMap<String, Set<String>> hh = new HashMap<String, Set<String>>();
					Set<String> al = new HashSet<String>();
					al.add(getValue(dateinfo[1], dateinfo[2]));
					hh.put(getKey(dateinfo[1]), al);
					h.put(dateinfo[0], hh);
					System.out.println("h" + h + ", hh" + hh + ", al" + al);
				}

				/*
				 * System.out.println(resultSet.getString("last_visited").substring
				 * (0,10) + "URL [" + resultSet.getString("url") + "]" +
				 * ", visit count [" + resultSet.getString("visit_count") +
				 * "]");
				 */
			}

		}

		catch (Exception e) {
			System.err.println(e);
			e.printStackTrace();
		}

		return h;
	}
}
