package com.pw.anand.dao;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.pw.anand.bean.WebPage;
import com.pw.anand.util.DBUtil;

public class SearchDao {
	
	
	List<String> contextList=new ArrayList<String>();
	List<String> contentList=new ArrayList<String>();
	
	
	
	
	
	
	

	public List<String> getContextList() {
		return contextList;
	}


	public void setContextList(List<String> contextList) {
		this.contextList = contextList;
	}


	public List<String> getContentList() {
		return contentList;
	}


	public void setContentList(List<String> contentList) {
		this.contentList = contentList;
	}


	public List<WebPage> webPagePrevSearch(String context, String content) {
		List<WebPage> result = null;
		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			System.out.println(dateFormat.format(date));
			Connection con = DBUtil.getInstance().getConnection();

			PreparedStatement pst = con
					.prepareStatement("select * from VURLS where upper(KEY_WORD) like '%"
							+ content.trim().toUpperCase()
							+ "%' or upper(KEY_WORD) like '%"
							+ context.trim().toUpperCase() + "%' order by COUNT desc");

			ResultSet rs = pst.executeQuery();
			result = new ArrayList<WebPage>();

			InetAddress IP = InetAddress.getLocalHost();
			String ips = IP.getHostAddress();
			while (rs.next()) {
				WebPage ws = new WebPage();
				ws.setWssno(rs.getString(1));
				ws.setUrl(rs.getString(2));
				ws.setMeta(rs.getString(3));
				ws.setDesc(rs.getString(4));
				//searchHis(dateFormat.format(date), ws, context, content, ips);
				//System.out.println(ws);
				result.add(ws);
			}
		} catch (SQLException e) {
			System.out.println(e);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public List<WebPage> search(String context, String content,String uid) {
		List<WebPage> result = null;
		
		try {

			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Date date = new Date();
			System.out.println(dateFormat.format(date));
			Connection con = DBUtil.getInstance().getConnection();

			
			
			/*PreparedStatement pstmt = con
			.prepareStatement("select * from URLS where upper(KEY_WORD) like '%"
					+ context.trim().toUpperCase()
					+ "%'");
			
			ResultSet rss=pstmt.executeQuery();
			while(rss.next())
			{
			
				contextList.add(rss.getString(1));
			}
			rss.close();
			pstmt.close();
			
			
			
			
			
			
			
			
			
			PreparedStatement pstmtt = con
			.prepareStatement("select * from URLS where upper(KEY_WORD) like '%"
					+ content.trim().toUpperCase()
					+ "%'");
			
			ResultSet rsss=pstmtt.executeQuery();
			while(rsss.next())
			{
			
				contentList.add(rsss.getString(1));
			}
			rsss.close();
			pstmtt.close();*/
			
			
			
			
			
			PreparedStatement pst = con
			.prepareStatement("select * from URLS where upper(KEY_WORD) like '%"
					+ content.trim().toUpperCase()
					+ "%' or upper(KEY_WORD) like '%"
					+ context.trim().toUpperCase() + "%'");

			ResultSet rs = pst.executeQuery();
			result = new ArrayList<WebPage>();

			InetAddress IP = InetAddress.getLocalHost();
			String ips = IP.getHostAddress();
			while (rs.next()) {
				WebPage ws = new WebPage();
				ws.setWssno(rs.getString(1));
				ws.setUrl(rs.getString(2));
				ws.setMeta(rs.getString(3));
				ws.setDesc(rs.getString(4));
				searchHis(dateFormat.format(date), ws, context, content, ips,uid);
				//System.out.println(ws);
				result.add(ws);
			}
		} catch (SQLException e) {
			//System.out.println(e);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return result;
	}

	public void searchHis(String todayDate, WebPage wp, String context,
			String content, String ips,String uid) {

		try {
			Connection con = DBUtil.getInstance().getConnection();

			//System.out.println("Select * from VURLS where SNO='"					+ wp.getWssno().trim() + "'");

			PreparedStatement pstStatement = con
					.prepareStatement("Select * from VURLS where SNO='"
							+ wp.getWssno().trim() + "'");

			ResultSet rs = pstStatement.executeQuery();
			boolean flag = false;
			int count = 0;
			if (rs.next()) {
				flag = true;
				count = rs.getInt("COUNT");
			}
			//System.out.println("COUNT" + count);
			if (!flag) {
				PreparedStatement pst = con
						.prepareStatement("Insert into VURLS values(?,?,?,?,?,?,?,?,?)");

				pst.setString(1, wp.getWssno());
				pst.setString(2, wp.getUrl());
				pst.setString(3, wp.getMeta());
				pst.setString(4, wp.getDesc());
				pst.setString(5, ips);
				pst.setString(6, todayDate);
				pst.setInt(7, 1);
				pst.setString(8, context);
				pst.setString(9, content);
				int i = pst.executeUpdate();
				if (i == 1) {
					con.commit();
					DBUtil.getInstance().closeConnection();
				}
				//System.out.println(i);

			} else {
				PreparedStatement ps = con
						.prepareStatement("Update VURLS set COUNT= "
								+ (count + 1) + " where SNO='"
								+ wp.getWssno().trim() + "'");
				int i = ps.executeUpdate();
				if (i == 1) {

				}
				System.out.println(i);

			}

			PreparedStatement pst = con
					.prepareStatement("Insert into SEARCH_HISTORY values(?,?,?,?,?,?,?,?,?,?)");

			String []contextArr=context.split(" ");
			if(contextArr!=null&&contextArr.length>1){
				context=contextArr[0];
			}
			pst.setString(1, wp.getWssno());
			pst.setString(2, wp.getUrl());
			pst.setString(3, wp.getMeta());
			pst.setString(4, wp.getDesc());
			pst.setString(5, ips);
			pst.setString(6, todayDate);
			pst.setInt(7, 1);
			pst.setString(8, context);
			pst.setString(9, content);
			pst.setString(10, uid);
			pst.executeUpdate();
			con.commit();
			DBUtil.getInstance().closeConnection();

		} catch (Exception e) {

		}
	}
}
