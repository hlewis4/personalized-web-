package com.pw.anand.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pw.anand.service.AnalysisImpl;

public class QuestionFormServlet extends HttpServlet {

	private static final long serialVersionUID = -7673705678004939542L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		
		String q1ans = request.getParameter("q1ans");
		String q2ans = request.getParameter("q2ans");
		String q3ans = request.getParameter("q3ans");
		String q4ans = request.getParameter("q4ans");
		String q5ans = request.getParameter("q5ans");
		String q6ans = request.getParameter("q6ans");
		String q7ans = request.getParameter("q7ans");
		List<Integer> answer = new ArrayList<Integer>();
		answer.add(0, Integer.valueOf(q1ans));
		answer.add(1, Integer.valueOf(q2ans));
		answer.add(2, Integer.valueOf(q3ans));
		answer.add(3, Integer.valueOf(q4ans));
		answer.add(4, Integer.valueOf(q5ans));
		answer.add(5, Integer.valueOf(q6ans));
		answer.add(6, Integer.valueOf(q7ans));

		//System.out.println("ans 1===="+ Integer.valueOf(q1ans));
		
		HttpSession hs=request.getSession(false);
		String uid=(String)hs.getAttribute("uid");
		
		System.out.println("userid=="+uid);
		
		if (new AnalysisImpl().putUserAnswer(answer,uid)) {
			request.setAttribute("status",
					"Thanks for your feedback i really appreciate it");
		} else {

			request.setAttribute("status",
					"Already Answers Submitted Thanq");
		}
		RequestDispatcher rd = request
				.getRequestDispatcher("user-satisfaction-analysis-form.jsp");
		rd.forward(request, response);

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		doGet(request, response);
	}

}
