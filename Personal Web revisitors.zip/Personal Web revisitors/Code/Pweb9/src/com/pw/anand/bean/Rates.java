package com.pw.anand.bean;

public class Rates
{
	private double rate;
	private double precision;
	private double recall;
	private double error;
	
	

	
	public double getError() {
		return error;
	}

	public void setError(double error) {
		this.error = error;
	}

	public double getRecall() {
		return recall;
	}

	public void setRecall(double recall) {
		this.recall = recall;
	}

	public double getPrecision() {
		return precision;
	}

	public void setPrecision(double precision) {
		this.precision = precision;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}
	
	
}
