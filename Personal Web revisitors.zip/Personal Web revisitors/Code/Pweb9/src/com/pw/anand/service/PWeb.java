package com.pw.anand.service;

import java.rmi.Remote;
import java.rmi.RemoteException;

import com.pw.anand.bean.PWebSearchResp;
import com.pw.anand.bean.WebPage;


public interface PWeb extends Remote {

	public PWebSearchResp personalWebSearch(String context, String content,String uid);
	public PWebSearchResp webPagePrevSearch(String context, String content);	
	public WebPage urlInfo(String context, String content)
	throws RemoteException;

}
