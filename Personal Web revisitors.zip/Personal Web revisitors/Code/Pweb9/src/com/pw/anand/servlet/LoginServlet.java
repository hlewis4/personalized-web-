package com.pw.anand.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pw.anand.bean.RegistrationBean;
import com.pw.anand.dao.UserDAO;

public class LoginServlet extends HttpServlet {
	private String utype = "";
	private String username = "";

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException 
			{
		UserDAO dao = new UserDAO();
		String user=request.getParameter("role");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		RegistrationBean rb = new RegistrationBean();
		
		String target = "UserLogin.jsp?status=Internal Proublem Please Try again!";
		try
		{
		rb.setUserID(request.getParameter("uid"));
		rb.setPassword(request.getParameter("pass"));
		RegistrationBean rb1 = new RegistrationBean();
		rb1 = dao.loginCheck(rb);
		
		utype = rb1.getUserType();
		username = rb1.getUserName();
		
		System.out.println("role======"+utype);
		
		
		session.setAttribute("uid", request.getParameter("uid"));
		
		if (utype.equals("ADMIN")) {
				target = "AdminHome.jsp?status=Welcome " + username+"&role=ADMIN";
				session.setAttribute("user", username);
				session.setAttribute("role", utype);
			
		
		} 
	else if (utype.equals("USER")) {
			
				target = "UserHome.jsp?status=Welcome " + username+"&role=ADMIN";
				session.setAttribute("user", username);
				session.setAttribute("role", utype);
		
				

		}
		
		else
		{
			target = "login.jsp?status=Invalid username or password&user="+user;
		}
		}
		catch(Exception e)
		{
			target = "login.jsp?status=Invalid username or password&user="+user;
		}

		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);

		out.flush();
		out.close();

	
	}
	

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		doGet(request, response);
		out.flush();
		out.close();
	}
	

}
