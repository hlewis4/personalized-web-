package com.pw.anand.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pw.anand.bean.RegistrationBean;
import com.pw.anand.dao.UserDAO;

public class SaveUserServlet extends HttpServlet {

	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		
		
		UserDAO dao=new UserDAO();
		
		String uid=req.getParameter("uid");
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String pwd=req.getParameter("pwd");
		String role=req.getParameter("role");
		String mobile=req.getParameter("mobile");
		
		RegistrationBean rb=new RegistrationBean();
		rb.setUserID(uid);
		rb.setUserName(name);
		rb.setEmail(email);
		rb.setPassword(pwd);
		rb.setMobile(mobile);
		rb.setUserType(role);
		
		int status=dao.saveUser(rb);
		
		if(status>0)
		{
			resp.sendRedirect("registration.jsp?status=Successfully Saved&user="+name);
		}
		else
		{
			resp.sendRedirect("registration.jsp?status="+name+" Already Registered");
		}
		
		
		
	}

}
