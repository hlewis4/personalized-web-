package com.pw.anand.service;

import java.util.List;

import com.pw.anand.dao.AnalysisDao;

public class AnalysisImpl implements Analysis {

	@Override
	public List<Float> getQuestionnaireResult() {
		return new AnalysisDao().getQuestionnaireResult();
	}

	@Override
	public boolean putUserAnswer(List<Integer> answer,String username) {

		return new AnalysisDao().putUserAnswer(answer, username);
	}

}
