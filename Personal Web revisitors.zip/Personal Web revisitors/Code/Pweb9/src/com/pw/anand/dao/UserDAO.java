package com.pw.anand.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import oracle.sql.ARRAY;

import com.pw.anand.bean.Context;
import com.pw.anand.bean.Rates;
import com.pw.anand.bean.RegistrationBean;
import com.pw.anand.util.DBUtil;

public class UserDAO
{
	PreparedStatement pstmt;
	PreparedStatement ps;
	PreparedStatement pst;
	Boolean flag=null;
	Connection con;
	public RegistrationBean loginCheck(RegistrationBean regbean) 
	{
		String loginid = regbean.getUserID();
		String password = regbean.getPassword();
		RegistrationBean regbean1 = new RegistrationBean();
		try {
			Connection con  = DBUtil.getInstance().getConnection();
			pst = con
					.prepareStatement(SqlConstants.SQL_LOGIN_CHECK);
			pst.setString(1, loginid);
			pst.setString(2, password);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				regbean1.setUserType(rs.getString(1));
				regbean1.setUserName(rs.getString(2));
				
			} else {
				flag = false;
				regbean1.setUserType("");
				regbean1.setUserName("");
				
				
			}
			pst.close();
		} catch (SQLException ex) {
			System.out.println(ex);
			
			flag = false;
		} 

		return regbean1;
		
	}
	public int saveUser(RegistrationBean rb) 
	{
		int status=0;
		try
		{
		con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement(SqlConstants.SQL_SAVE_USER_DETAILS);
			pst.setString(1, rb.getUserID());
			pst.setString(2,rb.getUserName());
			pst.setString(3,rb.getEmail());
			pst.setString(4,rb.getMobile());
		
			pst.setString(5, "USER");
			pst.setString(6,rb.getPassword());
			
			status=pst.executeUpdate();
			pst.close();
		}
		catch(Exception e)
		{
			
		}
		
		return status;
		
	}
	public int saveSearchContextWord(String uid, String context) 
	{
		int status=0;
		int count=0;
		try
		{
		con=DBUtil.getInstance().getConnection();
		
		pst=con.prepareStatement("select count from contextwords where userid=? and context=?");
		pst.setString(1, uid);
		pst.setString(2,context);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			count=rs.getInt(1);
		}
		pst.close();
				if(count==0)
				{
				
					pst=con.prepareStatement("insert into contextwords(userid,context,count) values(?,?,?)");
					pst.setString(1, uid);
					pst.setString(2,context);
					pst.setInt(3,count+1);
					status=pst.executeUpdate();
					pst.close();
				}
				else
				{
					pst=con.prepareStatement("update contextwords set count=? where userid=? and context=?");
					pst.setInt(1,count+1);
					pst.setString(2, uid);
					pst.setString(3,context);
					
					status=pst.executeUpdate();
					pst.close();
					
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		return status;
		
		
		
	}

	
	
	public int saveSearchContentWord(String uid, String content) 
	{
		int status=0;
		int count=0;
		try
		{
		con=DBUtil.getInstance().getConnection();
		
		pst=con.prepareStatement("select count from contentwords where userid=? and content=?");
		pst.setString(1, uid);
		pst.setString(2,content);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			count=rs.getInt(1);
		}
		pst.close();
				if(count==0)
				{
				
					pst=con.prepareStatement("insert into contentwords(userid,content,count) values(?,?,?)");
					pst.setString(1, uid);
					pst.setString(2,content);
					pst.setInt(3,count+1);
					status=pst.executeUpdate();
					pst.close();
				}
				else
				{
					pst=con.prepareStatement("update contentwords set count=? where userid=? and content=?");
					pst.setInt(1,count+1);
					pst.setString(2, uid);
					pst.setString(3,content);
					
					status=pst.executeUpdate();
					pst.close();
					
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		return status;
		
		
		
	}
	
	
	
	
	
	public int savePrevSearchContextWord(String uid, String context) 
	{
		int status=0;
		int count=0;
		try
		{
		con=DBUtil.getInstance().getConnection();
		
		pst=con.prepareStatement("select count from prev_context_words where userid=? and context=?");
		pst.setString(1, uid);
		pst.setString(2,context);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			count=rs.getInt(1);
		}
pst.close();
				if(count==0)
				{
				
					pst=con.prepareStatement("insert into prev_context_words(userid,context,count) values(?,?,?)");
					pst.setString(1, uid);
					pst.setString(2,context);
					pst.setInt(3,count+1);
					status=pst.executeUpdate();
					pst.close();
				}
				else
				{
					pst=con.prepareStatement("update prev_context_words set count=? where userid=? and context=?");
					pst.setInt(1,count+1);
					pst.setString(2, uid);
					pst.setString(3,context);
					
					status=pst.executeUpdate();
					pst.close();
					
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		return status;
		
		
		
	}

	
	
	public int savePrevSearchContentWord(String uid, String content) 
	{
		int status=0;
		int count=0;
		try
		{
		con=DBUtil.getInstance().getConnection();
		
		pst=con.prepareStatement("select count from prev_content_words where userid=? and content=?");
		pst.setString(1, uid);
		pst.setString(2,content);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
			count=rs.getInt(1);
		}
		pst.close();
				if(count==0)
				{
				
					pst=con.prepareStatement("insert into prev_content_words(userid,content,count) values(?,?,?)");
					pst.setString(1, uid);
					pst.setString(2,content);
					pst.setInt(3,count+1);
					status=pst.executeUpdate();
					pst.close();
				}
				else
				{
					pst=con.prepareStatement("update prev_content_words set count=? where userid=? and content=?");
					pst.setInt(1,count+1);
					pst.setString(2, uid);
					pst.setString(3,content);
					
					status=pst.executeUpdate();
					pst.close();
					
				}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
		return status;
		
	}
	
	
	
	
	public HashMap getgetContextWordsCount(String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select context,count from contextwords where userid=?");
			pst.setString(1, uid);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setWord(rs.getString(1));
				context.setCount(rs.getInt(2));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
	}
	
	
	public HashMap getHistory(String word,String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select url,wpdesc from search_history where context=? and userid=?");
			pst.setString(1, word);
			pst.setString(2, uid);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setUrl(rs.getString(1));
				context.setDesc(rs.getString(2));
				hm.put(i, context);
				
			}
			pst.close();
			
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
		
	}
	
	
	
	
	
	
	public HashMap getgetContentWordsCount(String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select content,count from contentwords where userid=?");
			pst.setString(1, uid);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setWord(rs.getString(1));
				context.setCount(rs.getInt(2));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
	}
	
	
	public HashMap getContentHistory(String word,String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select url,wpdesc from search_history where content=? and userid=?");
			pst.setString(1, word);
			pst.setString(2, uid);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setUrl(rs.getString(1));
				context.setDesc(rs.getString(2));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
		
	}
	
	
	public HashMap getprevContextWordsCount(String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select context,count from prev_context_words where userid=?");
			pst.setString(1, uid);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setWord(rs.getString(1));
				context.setCount(rs.getInt(2));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
	}
	
	
	
	
	
	public HashMap getprevContentWordsCount(String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select content,count from prev_content_words where userid=?");
			pst.setString(1, uid);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setWord(rs.getString(1));
				context.setCount(rs.getInt(2));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
	}
	
	
	
	
	public HashMap getUsers()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select userid,username,email,mobile from users where not role='ADMIN'");
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
			RegistrationBean rb=new RegistrationBean();
				rb.setUserID(rs.getString(1));
				rb.setUserName(rs.getString(2));
				rb.setEmail(rs.getString(3));
				rb.setMobile(rs.getString(4));
				hm.put(i, rb);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
	}
	
	
	
	
	public HashMap getTotalContextWordsCount()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select userid,context,count from contextwords order by userid,count");
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setUserId(rs.getString(1));
				context.setWord(rs.getString(2));
				context.setCount(rs.getInt(3));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
	}
	
	
	
	
	
	public HashMap getTotalContentWordsCount()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select userid,content,count from contentwords order by userid,count");
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setUserId(rs.getString(1));
				context.setWord(rs.getString(2));
				context.setCount(rs.getInt(3));
				hm.put(i, context);
				
			}
			
			pst.close();
		}
		
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return hm;
		
	}
	public HashMap getContentRankings() 
	{
		HashMap  hm=new HashMap();
		
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("SELECT content, avg(count) as avg FROM contentwords where content is not null GROUP BY content order by avg desc");
			ResultSet rs=pst.executeQuery();
			while (rs.next())
			{
				//System.out.println("inside while");
				i++;
				Context context=new Context();
				String content=rs.getString(1);
				
				//System.out.println("content======"+content);
				
				Double avg=rs.getDouble(2);
				
				//System.out.println("avg======"+avg);
				context.setWord(content);
				
				
				context.setAvg(avg);
				
				hm.put(i, context);
				
			}
			pst.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
		
	}
	
	
	
	public HashMap getContextRankings() 
	{
		HashMap  hm=new HashMap();
		
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("SELECT context, avg(count) as avg FROM contextwords where context is not null GROUP BY context order by avg desc");
			ResultSet rs=pst.executeQuery();
			while (rs.next())
			{
				i++;
				Context context=new Context();
				String content=rs.getString(1);
				Double avg=rs.getDouble(2);
				context.setWord(content);
				context.setAvg(avg);
				hm.put(i, context);
				
			}
			pst.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
		
	}
	
	
	
	public HashMap getUsersPrediction()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select userid,max(context) as word,count(context),ladate from search_history where userid is not null group by userid,context,ladate order by word,ladate,count(context) desc");
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context context=new Context();
				context.setUserId(rs.getString(1));
				context.setWord(rs.getString(2));
				context.setCount(rs.getInt(3));
				context.setDate(rs.getDate(4));
				hm.put(i, context);
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
	}
	
	
	
	
	public HashMap findingRateContent()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select sum(count) from contentwords");
			
			PreparedStatement pst1=con.prepareStatement("select count(url) from urls");
			ResultSet rs1=pst1.executeQuery();
			rs1.next();
			
			
			
			
			
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Rates r=new Rates();
				
				int val=rs.getInt(1);
				double val1=(float)1/val;
				 r.setRate(val1);
				 
				 
				 int urls=rs1.getInt(1);
				 float upper=(float)(urls/2)/urls;
				 double precision=(float)upper/val;
				 r.setPrecision(precision);
				 
				 
				 float upper1=(float)3/urls;
				 double recall=(float)upper1/val;
				 r.setRecall(recall);
				 
				 
				 
				 
				 float upper2=(float)(1*val)/(5*2);
				/* double error=(float)upper2/val;*/
				 /*System.out.println("val---"+upper2);*/
				 r.setError(upper2);
				 
				 
				 
				hm.put(i, r);
			}
			pst.close();
			pst1.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
	}
	
	
	
	
	
	public HashMap findingRateContext()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select sum(count) from contextwords");
			
			PreparedStatement pst1=con.prepareStatement("select count(url) from urls");
			ResultSet rs1=pst1.executeQuery();
			rs1.next();
			
			
			
			
			
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Rates r=new Rates();
				
				int val=rs.getInt(1);
				double val1=(float)1/val;
				 r.setRate(val1);
				 
				 
				 int urls=rs1.getInt(1);
				 float upper=(float)(urls/2)/urls;
				 double precision=(float)upper/val;
				 r.setPrecision(precision);
				 
				 
				 float upper1=(float)3/urls;
				 double recall=(float)upper1/val;
				 r.setRecall(recall);
				 
				 
				 
				 
				 float upper2=(float)(1*val)/(5*2);
				/* double error=(float)upper2/val;*/
				 /*System.out.println("val---"+upper2);*/
				 r.setError(upper2);
				 
				 
				 
				hm.put(i, r);
			}
			pst.close();
			pst1.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
	}
	
	
	
	
	
	public HashMap findingRateContext_Content()
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("SELECT (SELECT SUM(count) FROM contentwords) + (SELECT SUM(count) FROM contextwords) as result from dual");
			
			PreparedStatement pst1=con.prepareStatement("select count(url) from urls");
			ResultSet rs1=pst1.executeQuery();
			rs1.next();
			
			
			
			
			
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Rates r=new Rates();
				
				int val=rs.getInt(1);
				double val1=(float)1/val;
				 r.setRate(val1);
				 
				 
				 int urls=rs1.getInt(1);
				 float upper=(float)(urls/2)/urls;
				 double precision=(float)upper/val;
				 r.setPrecision(precision);
				 
				 
				 float upper1=(float)3/urls;
				 double recall=(float)upper1/val;
				 r.setRecall(recall);
				 
				 
				 
				 
				 float upper2=(float)(1*val)/(5*2);
				/* double error=(float)upper2/val;*/
				 /*System.out.println("val---"+upper2);*/
				 r.setError(upper2);
				 
				 
				 
				hm.put(i, r);
			}
			pst.close();
			pst1.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
	}
	
	
	
	public HashMap getContentGraph(String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select distinct c.content,(c.count+p.count)as val from contentwords c , prev_content_words p where c.userid='"+uid+"' and p.userid='"+uid+"' and c.content is not null and p.content is not null");
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context r=new Context();
				r.setWord(rs.getString(1));
				r.setCount(rs.getInt(2));
				 
				hm.put(i, r);
			}
			pst.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
	}
	
	
	
	public HashMap getContextGraph(String uid)
	{
		HashMap hm=new HashMap();
		try
		{
			int i=0;
			con=DBUtil.getInstance().getConnection();
			pst=con.prepareStatement("select distinct c.context,(c.count+p.count)as val from contextwords c , prev_context_words p where c.userid='"+uid+"' and p.userid='"+uid+"' and c.context is not null and p.context is not null");
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				i++;
				Context r=new Context();
				r.setWord(rs.getString(1));
				r.setCount(rs.getInt(2));
				 
				hm.put(i, r);
			}
			pst.close();
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return hm;
	}
	
	
	
	
	
	
	
	
	
	

}
