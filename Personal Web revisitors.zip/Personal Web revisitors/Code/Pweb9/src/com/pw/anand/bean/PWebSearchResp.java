package com.pw.anand.bean;

import java.io.Serializable;
import java.util.List;

public class PWebSearchResp implements Serializable {
	private static final long serialVersionUID = 119581160435977105L;
	private List<WebPage> searchResult;

	public List<WebPage> getSearchResult() {
		return searchResult;
	}

	public void setSearchResult(List<WebPage> searchResult) {
		this.searchResult = searchResult;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PWebSearchResp [searchResult=");
		builder.append(searchResult);
		builder.append("]");
		return builder.toString();
	}

}
