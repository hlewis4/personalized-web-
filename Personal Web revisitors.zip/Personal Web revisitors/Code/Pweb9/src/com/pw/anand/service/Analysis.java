package com.pw.anand.service;

import java.util.List;

public interface Analysis {
	public boolean putUserAnswer(List<Integer> answer,String username);

	public List<Float> getQuestionnaireResult();
}
