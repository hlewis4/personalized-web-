package com.pw.anand.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	private static DBUtil instance = null;

	private DBUtil() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
		}

	}

	public static DBUtil getInstance() {
		if (instance == null) {
			instance = new DBUtil();
		}
		return instance;
	}

	static final ThreadLocal<Connection> session = new ThreadLocal<Connection>();

	public Connection getConnection() throws SQLException {
		Connection con = session.get();
		if (con == null) {
				con = DriverManager.getConnection(
						"jdbc:oracle:thin:@localhost:1521:XE", "web", "web");
			
		}
		return con;

	}

	public void closeConnection() throws SQLException {
		Connection con = session.get();
		session.set(null);
		if (con != null) {
			con.close();
		}
	}
}
