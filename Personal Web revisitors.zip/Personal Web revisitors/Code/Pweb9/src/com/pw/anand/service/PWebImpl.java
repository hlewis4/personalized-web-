package com.pw.anand.service;

import java.rmi.RemoteException;

import com.pw.anand.bean.PWebSearchResp;
import com.pw.anand.bean.WebPage;
import com.pw.anand.dao.SearchDao;

public class PWebImpl implements PWeb {

	public PWebSearchResp personalWebSearch(String context, String content,String uid) {

		PWebSearchResp resp = new PWebSearchResp();
		resp.setSearchResult(new SearchDao().search(context, content,uid));

		System.out.println(resp);
		return resp;
	}
	
	public PWebSearchResp webPagePrevSearch(String context, String content) {

		PWebSearchResp resp = new PWebSearchResp();
		resp.setSearchResult(new SearchDao().webPagePrevSearch(context, content));

		//System.out.println(resp);
		return resp;
	}

	public WebPage urlInfo(String context, String content)
			throws RemoteException {
		WebPage wp = new WebPage();

		wp.setDesc("des");
		wp.setMeta("nit");
		wp.setUrl("url");
		wp.setWssno("2");
		return wp;
	}

}
