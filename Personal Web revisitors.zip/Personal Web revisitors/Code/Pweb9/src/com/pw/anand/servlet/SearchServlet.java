package com.pw.anand.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pw.anand.bean.PWebSearchResp;
import com.pw.anand.dao.SearchDao;
import com.pw.anand.dao.UserDAO;
import com.pw.anand.service.PWeb;
import com.pw.anand.service.PWebImpl;

public class SearchServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SearchServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		out.print("uuuu");

		String context = request.getParameter("context");
		String content = request.getParameter("content");
		
		HttpSession hs=request.getSession(false);
		String uid=(String)hs.getAttribute("uid");
		
		
		int i=new UserDAO().saveSearchContextWord(uid,context);
		int j=new UserDAO().saveSearchContentWord(uid,content);
		
		
		PWeb service = new PWebImpl();
		PWebSearchResp result = service.personalWebSearch(context, content,uid);
	
		SearchDao dao=new SearchDao();
		/*List<String> contentList=dao.getContentList();
		
		List<String> contextList=dao.getContextList();
		
		System.out.println("content list========"+contentList.size());
		
		System.out.println("context list========"+contextList.size());*/
		
		
		System.out.println("uid----------"+uid);
	
		
		
		
		
		HttpSession session = request.getSession();
		session.setAttribute("result", result);
		//out.print(result);
		RequestDispatcher rd = request
				.getRequestDispatcher("search-result.jsp");
		rd.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
